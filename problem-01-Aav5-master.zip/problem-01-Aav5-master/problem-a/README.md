# Problem: Basics

In this exercise, you'll practice creating a basic web page using HTML and CSS. You will also practice using Jest to run unit tests, as well as using `git` and GitHub to manage, submit, and publish assignments for this course.

To complete this exercise, follow the instructions detailed on the Canvas assignment page (they are published online for easier editing).
